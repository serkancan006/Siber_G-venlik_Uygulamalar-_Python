# tor_ip_degistirici

Çalıştırmadan önce yapılması gerekenler;

apt-get install tor

service tor start

service tor status


Çalıştırılması;

python ip_degistirici.py
